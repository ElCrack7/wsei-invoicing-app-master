export class Item {
    name: string;
}
